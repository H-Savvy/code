package org.instrumentos;

import java.util.Scanner;
import org.instrumentos.servicio.ServicioInstrumentos;

public class AppInstrumentos {
	static Scanner sca = new Scanner(System.in);
		
	public static void main(String[] args) {
		int CantInstrumentos;
		Instrumentos v;
		ServicioInstrumentos servicioInstrumentos;
		System.out.println("Cuantos Instrumentos tiene?");
		CantInstrumentos = sca.nextInt();
		servicioInstrumentos = new ServicioInstrumentos(CantInstrumentos);
		while (true) {
			   System.out.println("Instrumentos\n");
				System.out.println("1. Nuevo instrumento en Venta");
				System.out.println("2. Ver instrumentos");
				System.out.println("3. Ver guitarras");
				System.out.println("4. Ver ukuleles");
				System.out.println("5. violines");
				System.out.println("0. Salir");
				System.out.print("Ingrese opcion: ");
				int opcion = sca.nextInt();
				switch(opcion) {
				case 1:
					
					break;
				case 2:
					System.out.println("Estos son todos los Instrumentos");
					servicioInstrumentos.mostrarInstrumento();
					break;
				case 3:
					System.out.println("Estos son todos las guitarras");
					v = new Guitarra();
					servicioInstrumentos.mostrarInstrumento(v);
					break;
				case 4:
					System.out.println("Estos son todos los ukuleles");
					v = new Ukulele();
					servicioInstrumentos.mostrarInstrumento(v);
					break;
				case 5:
					System.out.println("Estos son todos los violines");
					v = new violin();
					servicioInstrumentos.mostrarInstrumento(v);
					break;
				case 0:
					System.exit(0);
					break;
				default:
					System.out.print("Opcion invalida");
					break;
			}
		   }
	}

}
