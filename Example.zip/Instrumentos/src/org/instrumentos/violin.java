package org.instrumentos;

public class violin extends Instrumentos {
	private String marca;

	public violin() {
		super("","","",0);
		this.marca = "";
	}

	public violin(String nombre,String cuerdas, String tamanio, int precio) {
		super(nombre,cuerdas, tamanio, precio);
		this.marca = "";
	}
	
	public violin(String nombre,String cuerdas, String tamanio, int precio, String marca) {
		super(nombre,cuerdas, tamanio, precio);
		this.marca = marca;
	}

	@Override
	public String toString() {
		return "violin [marca=" + marca + ", nombre=" + nombre + ", cuerdas=" + cuerdas + ", tamanio=" + tamanio
				+ ", precio=" + precio + "]";
	}
	
	
}
