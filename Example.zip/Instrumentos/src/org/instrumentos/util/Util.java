package org.instrumentos.util;

public class Util {
	public static String[] nombre = {"Guitarra", "Ukulele","violin"};
	public static String[] cuerdas = {"delgadas","semiDelgadas","gruesas"};
	public static String[] madera = {"lisa","pino","roble"};
	public static String[] tamanio = {"pequenio","mediano","grande"};
	public static String[] color = {"blanco","negro","cafe"};
	public static String[] marca = {"Ibaniez","Lexx","Goddy"};
	public static int[] precio = {500,1000,1500};
	
	public static int generarAleatorio(int min, int max) {
		return (int) ((Math.random()*(max-min))+min);
	}
	public static String retornarTipo(int t) {
		return nombre[t];
	}
	
}
