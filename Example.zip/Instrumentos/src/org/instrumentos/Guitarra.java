package org.instrumentos;

public class Guitarra extends Instrumentos {
	protected String madera;

	
	public Guitarra() {
		super("","","",0);
		this.madera = "";
	}


	public Guitarra(String nombre,String cuerdas, String tamanio, int precio) {
		super(nombre, cuerdas, tamanio, precio);
		this.madera = "";
	}


	public Guitarra(String nombre,String cuerdas, String tamanio, int precio, String madera) {
		super(nombre, cuerdas, tamanio, precio);
		this.madera = madera;
	}


	@Override
	public String toString() {
		return "Guitarra [madera=" + madera + ", nombre=" + nombre + ", cuerdas=" + cuerdas + ", tamanio=" + tamanio
				+ ", precio=" + precio + "]";
	}


	
	
	
}
