package org.instrumentos;

public class Ukulele extends Instrumentos {
	protected String color;

	public Ukulele() {
		super("","","",0);
		this.color ="";
	}

	public Ukulele(String nombre,String cuerdas, String tamanio, int precio) {
		super(nombre,cuerdas, tamanio, precio);
		this.color = "";
	}

	public Ukulele(String nombre,String cuerdas, String tamanio, int precio, String color) {
		super(nombre,cuerdas, tamanio, precio);
		this.color = color;
	}

	@Override
	public String toString() {
		return "Ukulele [color=" + color + ", nombre=" + nombre + ", cuerdas=" + cuerdas + ", tamanio=" + tamanio
				+ ", precio=" + precio + "]";
	}

	
	
	
}
