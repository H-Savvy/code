package org.instrumentos.servicio;
import org.instrumentos.util.Util;
import java.util.ArrayList;
import org.instrumentos.Guitarra;
import org.instrumentos.Instrumentos;
import org.instrumentos.Ukulele;
import org.instrumentos.violin;
public class ServicioInstrumentos {
	private ArrayList<Instrumentos> instrumentos;

	public ServicioInstrumentos(int cantidad) {
		this.instrumentos = new ArrayList<Instrumentos>();
		this.generarInstrumento(cantidad);
	}

	public void generarInstrumento(int cant) {
		Instrumentos v = null;
		for (int i=0;i<cant;i++) {
			int aleatotio = Util.generarAleatorio(0, 3);
			String nombre = Util.retornarTipo(aleatotio);
			String cuerdas = Util.cuerdas[Util.generarAleatorio(0, 3)];
			String tamanio = Util.tamanio[Util.generarAleatorio(0,3)];
			int precio = Util.generarAleatorio(500, 1500);
			
			if(nombre.equals("Guitarra")) {
				String madera = Util.madera[Util.generarAleatorio(0, 3)];
				v = new Guitarra(nombre, cuerdas,tamanio, precio, madera);
			}
			else if(nombre.equals("Ukulele")) {
				String color = Util.color[Util.generarAleatorio(0, 3)];
				v = new Ukulele(nombre,cuerdas,tamanio,precio,color);
			}
			else if(nombre.equals("violin")) {
				String marca = Util.marca[Util.generarAleatorio(0, 3)];
				v = new violin(nombre,cuerdas,tamanio,precio,marca);
			}
			this.instrumentos.add(v);
		}
	}
	
	public void mostrarInstrumento() {
		System.out.println("\n--inicio del listado--");
		for(int i=0;i<instrumentos.size();i++) {
			System.out.println(this.instrumentos.get(i));
		}
		System.out.println("\n--fin del listado--");
	}
	public void mostrarInstrumento(Instrumentos v) {
		System.out.println("\n--inicio del listado--");
		for(int i=0;i<instrumentos.size();i++) {
			if(this.instrumentos.get(i).getClass() == v.getClass())
				System.out.println(this.instrumentos.get(i));
		}
		System.out.println("\n--fin del listado--");
	}
	public ArrayList<Instrumentos> getMedicamento() {
		return instrumentos;
	}
	public void setMedicamentos(ArrayList<Instrumentos> medicamentos) {
		this.instrumentos = medicamentos;
	}
	
}
