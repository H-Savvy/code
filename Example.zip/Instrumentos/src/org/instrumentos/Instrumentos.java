package org.instrumentos;

public class Instrumentos {
	protected String nombre;
	protected String cuerdas;
	protected String tamanio;
	protected int precio;
	
	
	
	public Instrumentos() {
		this.nombre = "";
		this.cuerdas = "";
		this.tamanio = "";
		this.precio = 0;
	}



	public Instrumentos(String nombre,String cuerdas, String tamanio, int precio) {
		super();
		this.nombre = nombre;
		this.cuerdas = cuerdas;
		this.tamanio = tamanio;
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Instrumentos [nombre=" + nombre + ", cuerdas=" + cuerdas + ", tamanio=" + tamanio + ", precio=" + precio
				+ "]";
	}



	
	
	
}
